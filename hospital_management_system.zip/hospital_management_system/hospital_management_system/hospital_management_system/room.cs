﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hospital_management_system
{
    public partial class room : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=hospital;Integrated Security=True");

        public room()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into room(roomno,roomtype,status)values('" + txtRoomNo.Text + "','" + txtRoomType.Text + "','" + comboBoxStatus.SelectedItem + "')", con);
                cmd.ExecuteNonQuery();
                if (txtRoomType.Text != "" && txtRoomNo.Text != "" && comboBoxStatus.SelectedItem != "")
                {
                    MessageBox.Show("Record has been saved");
                }
                else
                {
                    MessageBox.Show("Failed saving a record");
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            finally {
                con.Close();
            }
            txtRoomNo.Text = ""; txtRoomType.Text = "";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            success sc = new success();
            sc.Show();
            this.Hide();
        }
    }
}
