﻿namespace hospital_management_system
{
    partial class success
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnBill = new System.Windows.Forms.Button();
            this.btnOutPatient = new System.Windows.Forms.Button();
            this.btnInpatient = new System.Windows.Forms.Button();
            this.btnRoom = new System.Windows.Forms.Button();
            this.btnLab = new System.Windows.Forms.Button();
            this.btnDoctor = new System.Windows.Forms.Button();
            this.btnPatient = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(285, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Administration Dashboard";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.btnBill);
            this.panel1.Controls.Add(this.btnOutPatient);
            this.panel1.Controls.Add(this.btnInpatient);
            this.panel1.Controls.Add(this.btnRoom);
            this.panel1.Controls.Add(this.btnLab);
            this.panel1.Controls.Add(this.btnDoctor);
            this.panel1.Controls.Add(this.btnPatient);
            this.panel1.Location = new System.Drawing.Point(12, 110);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(729, 537);
            this.panel1.TabIndex = 1;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(41, 349);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(646, 23);
            this.button7.TabIndex = 14;
            this.button7.Text = "Bill Report";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(41, 320);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(646, 23);
            this.button6.TabIndex = 13;
            this.button6.Text = "Out Patient Report";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(41, 291);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(646, 23);
            this.button5.TabIndex = 12;
            this.button5.Text = "In Patient Report";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(41, 262);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(646, 23);
            this.button4.TabIndex = 11;
            this.button4.Text = "Room Report";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(41, 233);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(646, 23);
            this.button3.TabIndex = 10;
            this.button3.Text = "Laboratory Report";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(41, 204);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(646, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Patient\'s Report";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(41, 175);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(646, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Doctor\'s Report";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(612, 37);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 97);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnBill
            // 
            this.btnBill.Location = new System.Drawing.Point(531, 37);
            this.btnBill.Name = "btnBill";
            this.btnBill.Size = new System.Drawing.Size(75, 97);
            this.btnBill.TabIndex = 6;
            this.btnBill.Text = "Bill";
            this.btnBill.UseVisualStyleBackColor = true;
            this.btnBill.Click += new System.EventHandler(this.btnBill_Click);
            // 
            // btnOutPatient
            // 
            this.btnOutPatient.Location = new System.Drawing.Point(450, 37);
            this.btnOutPatient.Name = "btnOutPatient";
            this.btnOutPatient.Size = new System.Drawing.Size(75, 97);
            this.btnOutPatient.TabIndex = 5;
            this.btnOutPatient.Text = "Out Patient";
            this.btnOutPatient.UseVisualStyleBackColor = true;
            this.btnOutPatient.Click += new System.EventHandler(this.btnOutPatient_Click);
            // 
            // btnInpatient
            // 
            this.btnInpatient.Location = new System.Drawing.Point(369, 37);
            this.btnInpatient.Name = "btnInpatient";
            this.btnInpatient.Size = new System.Drawing.Size(75, 97);
            this.btnInpatient.TabIndex = 4;
            this.btnInpatient.Text = "In Patient";
            this.btnInpatient.UseVisualStyleBackColor = true;
            this.btnInpatient.Click += new System.EventHandler(this.btnInpatient_Click);
            // 
            // btnRoom
            // 
            this.btnRoom.Location = new System.Drawing.Point(288, 37);
            this.btnRoom.Name = "btnRoom";
            this.btnRoom.Size = new System.Drawing.Size(75, 97);
            this.btnRoom.TabIndex = 3;
            this.btnRoom.Text = "Room";
            this.btnRoom.UseVisualStyleBackColor = true;
            this.btnRoom.Click += new System.EventHandler(this.btnRoom_Click);
            // 
            // btnLab
            // 
            this.btnLab.Location = new System.Drawing.Point(207, 37);
            this.btnLab.Name = "btnLab";
            this.btnLab.Size = new System.Drawing.Size(75, 97);
            this.btnLab.TabIndex = 2;
            this.btnLab.Text = "Laboratory";
            this.btnLab.UseVisualStyleBackColor = true;
            this.btnLab.Click += new System.EventHandler(this.btnLab_Click);
            // 
            // btnDoctor
            // 
            this.btnDoctor.Location = new System.Drawing.Point(41, 37);
            this.btnDoctor.Name = "btnDoctor";
            this.btnDoctor.Size = new System.Drawing.Size(75, 97);
            this.btnDoctor.TabIndex = 1;
            this.btnDoctor.Text = "Doctor";
            this.btnDoctor.UseVisualStyleBackColor = true;
            this.btnDoctor.Click += new System.EventHandler(this.btnDoctor_Click);
            // 
            // btnPatient
            // 
            this.btnPatient.Location = new System.Drawing.Point(126, 37);
            this.btnPatient.Name = "btnPatient";
            this.btnPatient.Size = new System.Drawing.Size(75, 97);
            this.btnPatient.TabIndex = 0;
            this.btnPatient.Text = "Patient";
            this.btnPatient.UseVisualStyleBackColor = true;
            this.btnPatient.Click += new System.EventHandler(this.btnPatient_Click);
            // 
            // success
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(886, 659);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "success";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "success";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnInpatient;
        private System.Windows.Forms.Button btnRoom;
        private System.Windows.Forms.Button btnLab;
        private System.Windows.Forms.Button btnDoctor;
        private System.Windows.Forms.Button btnPatient;
        private System.Windows.Forms.Button btnOutPatient;
        private System.Windows.Forms.Button btnBill;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}