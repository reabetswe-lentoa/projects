﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hospital_management_system
{
    public partial class InPatient : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=hospital;Integrated Security=True");

        public InPatient()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into inpatient(pid,roomno,dateofadmit,dateofdisch,labno)values('" + txtPatientId.Text + "','" + txtRoomNo.Text + "','" + dateTimePickerAdmitDate.Value.Date + "','" + dateTimePickerDishcargeDate.Value.Date + "','" + txtLabNo.Text + "')", con);
                cmd.ExecuteNonQuery();
                if (txtLabNo.Text != "" && txtPatientId.Text != "" && txtRoomNo.Text != "")
                {
                    MessageBox.Show("Record saved");
                }
                else
                {
                    MessageBox.Show("Failed saving a record");
                }
                con.Close();
            }
            catch (SqlException ex) 
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtLabNo.Text = "";
            txtPatientId.Clear();
            txtRoomNo.Clear();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            success sc = new success();
            sc.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("update inpatient set roomno='" + txtRoomNo.Text + "', dateofadmit='" + dateTimePickerAdmitDate.Value.Date + "', dateofdisch='"+dateTimePickerDishcargeDate.Value.Date+"' where labno='" + txtLabNo.Text + "'", con);
                cmd.ExecuteNonQuery();

                if (txtPatientId.Text != "" && txtLabNo.Text != "" && txtRoomNo.Text != "")
                {
                    MessageBox.Show("Update successful");
                }
                else
                {
                    MessageBox.Show("Update not successful");
                }
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtLabNo.Text = "";
            txtPatientId.Clear();
            txtRoomNo.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("delete from inpatient where pid='" + txtPatientId.Text + "'", con);
                cmd.ExecuteNonQuery();
                if (txtPatientId.Text != "")
                {
                    MessageBox.Show("Delete successful");
                }
                else
                {
                    MessageBox.Show("Delete not successful");
                }
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtPatientId.Clear();
        }
    }
}
