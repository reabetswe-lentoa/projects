﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hospital_management_system
{
    public partial class doctor : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=hospital;Integrated Security=True");

        public doctor()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into doctor(doctorid,doctorname,dept)values('" + txtDoctorId.Text + "','" + txtDoctorName.Text + "','" + txtDepartment.Text + "')", con);
                cmd.ExecuteNonQuery();

                if (txtDepartment.Text != "" && txtDoctorId.Text != "" && txtDoctorName.Text != "")
                {
                    MessageBox.Show("Record has been saved");
                }
                else
                {
                    MessageBox.Show("Failed saving a record");
                }
                con.Close();
            }
            catch (SqlException ex) 
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtDepartment.Text = ""; txtDoctorId.Text = ""; txtDoctorName.Text = "";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            success sc = new success();
            sc.Show();
            this.Hide();
        }

        private void doctor_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hospitalDataSet3.doctor' table. You can move, or remove it, as needed.
            this.doctorTableAdapter.Fill(this.hospitalDataSet3.doctor);
            // TODO: This line of code loads data into the 'hospitalDataSet.doctor' table. You can move, or remove it, as needed.
            //this.doctorTableAdapter.Fill(this.hospitalDataSet.doctor);

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("Select * From doctor Where doctorname Like'%" + txtSearch.Text + "%'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                con.Close();
            }
            catch (SqlException ex) 
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                
                SqlCommand cmd = new SqlCommand("update doctor set doctorname='" + txtDoctorName.Text + "', dept='" + txtDepartment.Text + "' where doctorid='" + txtDoctorId.Text + "'", con);
                cmd.ExecuteNonQuery();

                if (txtDepartment.Text != "" && txtDoctorId.Text != "" && txtDoctorName.Text != "") 
                {
                    MessageBox.Show("Update successful");
                }
                else
                {
                    MessageBox.Show("Data not updated");
                }
                con.Close();
            }
            catch (SqlException ex) 
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtDepartment.Text = ""; txtDoctorId.Text = ""; txtDoctorName.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("delete from doctor where doctorid='" + txtDoctorId.Text + "'", con);
                cmd.ExecuteNonQuery();

                if (txtDoctorId.Text != "")
                {
                    MessageBox.Show("Delete successful");
                }
                else
                {
                    MessageBox.Show("Delete not successful");
                }
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtDoctorId.Clear();
        }

        private void btnPrintData_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.dataGridView1.Width, this.dataGridView1.Height);
            dataGridView1.DrawToBitmap(bm, new Rectangle(0, 0, this.dataGridView1.Width, this.dataGridView1.Height));
            e.Graphics.DrawImage(bm, 0, 0);
        }
    }
}
