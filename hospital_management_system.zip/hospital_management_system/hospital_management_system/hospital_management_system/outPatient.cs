﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hospital_management_system
{
    public partial class outPatient : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=hospital;Integrated Security=True");

        public outPatient()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into outpatient(pid,dateout,labno)values('" + txtPatientId.Text + "','" + dateTimePickerDateOut.Value.Date + "','" + txtLabNo.Text + "')", con);
                cmd.ExecuteNonQuery();
                if (txtLabNo.Text != "" && txtPatientId.Text != "")
                {
                    MessageBox.Show("Record saved");
                }
                else
                {
                    MessageBox.Show("Failed saving a record");
                }
            }
            catch (SqlException ex) 
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtLabNo.Text = "";
            txtPatientId.Text = "";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            success sc = new success();
            sc.Show();
            this.Hide();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("update outpatient set dateout='" + dateTimePickerDateOut.Value.Date + "', labno='" + txtLabNo.Text + "' where pid='" + txtPatientId.Text + "'", con);
                cmd.ExecuteNonQuery();
                if (txtPatientId.Text != "" && txtLabNo.Text != "")
                {
                    MessageBox.Show("Update successful");
                }
                else
                {
                    MessageBox.Show("Update not successful");
                }
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtLabNo.Text = "";
            txtPatientId.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("delete from outpatient where pid='" + txtPatientId.Text + "'", con);
                cmd.ExecuteNonQuery();
                if (txtPatientId.Text != "")
                {
                    MessageBox.Show("Delete successful");
                }
                else
                {
                    MessageBox.Show("delete not successful");
                }
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtPatientId.Clear();
        }
    }
}
