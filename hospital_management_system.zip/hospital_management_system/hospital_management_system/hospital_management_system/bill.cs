﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hospital_management_system
{
    public partial class bill : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=hospital;Integrated Security=True");

        public bill()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //calculate bill
            txtBill.Text = (Convert.ToDouble(txtDoctorCharge.Text) + Convert.ToDouble(txtMedicineCharge.Text) + Convert.ToDouble(txtRoomCharge.Text) * Convert.ToInt32(txtNoOfDays.Text)).ToString();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into bill(billno,pid,patienttype,doctorcharge,medicinecharge,roomcharge,noofdays,bill) values('"+txtBillNo.Text+"','"+txtPatientId.Text+"','"+txtPatientType.Text+"','"+txtDoctorCharge.Text+"','"+txtMedicineCharge.Text+"','"+txtRoomCharge.Text+"','"+txtNoOfDays.Text+"','"+txtBill.Text+"')", con);
                cmd.ExecuteNonQuery();
                if (txtBill.Text != "" && txtBillNo.Text != "" && txtDoctorCharge.Text != "" && txtMedicineCharge.Text != "" && txtNoOfDays.Text != "" && txtPatientId.Text != "" && txtPatientType.Text != "" && txtRoomCharge.Text != "")
                {
                    MessageBox.Show("Record saved");
                }
                else
                {
                    MessageBox.Show("Record not saved");
                }
                con.Close();
            }
            catch (SqlException ex) 
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtBill.Clear();
            txtBillNo.Clear();
            txtDoctorCharge.Clear();
            txtMedicineCharge.Clear();
            txtNoOfDays.Clear();
            txtPatientId.Clear();
            txtPatientType.Clear();
            txtRoomCharge.Clear();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            success sc = new success();
            sc.Show();
            this.Hide();
        }

        private void bill_Load(object sender, EventArgs e)
        {
            txtBill.ReadOnly = true;
        }

        private void btnCalculateBill_Click(object sender, EventArgs e)
        {
            //calculate bill
            txtBill.Text = (Convert.ToDouble(txtDoctorCharge.Text) + Convert.ToDouble(txtMedicineCharge.Text) + Convert.ToDouble(txtRoomCharge.Text) * Convert.ToInt32(txtNoOfDays.Text)).ToString();
        }
    }
}
