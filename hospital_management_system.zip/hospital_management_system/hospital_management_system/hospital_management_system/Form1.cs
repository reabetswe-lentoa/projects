﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hospital_management_system
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=hospital;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from admin where username='" + txtUserName.Text + "' and password='" + txtPassword.Text + "'", con);
                cmd.ExecuteNonQuery();
                SqlDataReader dr;

                dr = cmd.ExecuteReader();
                int count = 0;

                while (dr.Read())
                {
                    count++;
                }
                if (count == 1)
                {
                    success sc = new success();
                    sc.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Login failed. Please try again");
                }
                con.Close();

            }
            catch (SqlException ex) {
                MessageBox.Show("Login failed. Please try again").ToString();
            }
        }
    }
}
