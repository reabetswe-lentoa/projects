﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital_management_system
{
    public partial class success : Form
    {
        public success()
        {
            InitializeComponent();
        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            patient p = new patient();
            p.Show();
            this.Hide();
        }

        private void btnDoctor_Click(object sender, EventArgs e)
        {
            doctor d = new doctor();
            d.Show();
            this.Hide();
        }

        private void btnLab_Click(object sender, EventArgs e)
        {
            labor lab = new labor();
            lab.Show();
            this.Hide();
        }

        private void btnRoom_Click(object sender, EventArgs e)
        {
            room r = new room();
            r.Show();
            this.Hide();
        }

        private void btnInpatient_Click(object sender, EventArgs e)
        {
            InPatient ip = new InPatient();
            ip.Show();
            this.Hide();
        }

        private void btnOutPatient_Click(object sender, EventArgs e)
        {
            outPatient outp = new outPatient();
            outp.Show();
            this.Hide();
        }

        private void btnBill_Click(object sender, EventArgs e)
        {
            bill b = new bill();
            b.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Confirm", MessageBoxButtons.YesNo) != DialogResult.No) 
            {
                Application.Exit();
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            doctor_report dr = new doctor_report();
            dr.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            patient_report pr = new patient_report();
            pr.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lab_report lr = new lab_report();
            lr.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            room_report rr = new room_report();
            rr.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            in_patient_report ipr = new in_patient_report();
            ipr.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            out_patient_report opr = new out_patient_report();
            opr.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            bill_report br = new bill_report();
            br.Show();
            this.Hide();
        }
    }
}
