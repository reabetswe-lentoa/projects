﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hospital_management_system
{
    public partial class labor : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=hospital;Integrated Security=True");

        public labor()
        {
            InitializeComponent();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into lab(labno,pid,weight,doctorid,datein,category,patienttype,amount)values('" + txtLabNo.Text + "','" + txtPatientId.Text + "','" + txtWeight.Text + "','" + txtDoctorId.Text + "','" + dateTimePickerDateIn.Value.Date + "','" + txtCategory.Text + "','" + txtPatientType.Text + "','" + txtAmount.Text + "')", con);
                cmd.ExecuteNonQuery();
                if (txtAmount.Text != "" && txtCategory.Text != "" && txtDoctorId.Text != "" && txtLabNo.Text != "" && txtPatientId.Text != "" && txtPatientType.Text != "" && txtWeight.Text != "")
                {
                    MessageBox.Show("Record has been saved");
                }
                else
                {
                    MessageBox.Show("Failed saving record");
                }
                con.Close();
            }
            catch (SqlException ex) 
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtAmount.Text = "";
            txtCategory.Text = "";
            txtDoctorId.Clear();
            txtLabNo.Clear();
            txtPatientId.Clear();
            txtPatientType.Clear();
            txtWeight.Clear();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            success sc = new success();
            sc.Show();
            this.Hide();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("update lab set pid='" + txtPatientId.Text + "', weight='" + txtWeight.Text + "', doctorid='" + txtDoctorId.Text + "', datein='"+dateTimePickerDateIn.Value.Date+"', category='"+txtCategory.Text+"',patienttype='"+txtPatientType.Text+"', amount='"+txtAmount.Text+"' where labno='" + txtLabNo.Text + "'", con);
                cmd.ExecuteNonQuery();
                if (txtAmount.Text != "" && txtCategory.Text != "" && txtDoctorId.Text != "" && txtLabNo.Text != "" && txtPatientId.Text != "" && txtPatientType.Text != "" && txtWeight.Text != "")
                {
                    MessageBox.Show("Update successful");
                }
                else
                {
                    MessageBox.Show("Update not successful");
                }
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtAmount.Text = "";
            txtCategory.Text = "";
            txtDoctorId.Clear();
            txtLabNo.Clear();
            txtPatientId.Clear();
            txtPatientType.Clear();
            txtWeight.Clear();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("delete from lab where labno='" + txtLabNo.Text + "'", con);
                cmd.ExecuteNonQuery();
                if (txtLabNo.Text != "")
                {
                    MessageBox.Show("Delete successful");
                }
                else
                {
                    MessageBox.Show("Delete not successful");
                }
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtLabNo.Clear();
        }
    }
}
