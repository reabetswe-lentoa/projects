﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hospital_management_system
{
    public partial class patient : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=hospital;Integrated Security=True");

        public patient()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into patient(pid,name,age,weight,gender,address,phone,disease,doctorid)values('" + txtPatientId.Text + "','" + txtPatientName.Text + "','" + txtAge.Text + "','" + txtWeight.Text + "','" + comboBoxGender.SelectedItem + "','" + richTextAddress.Text + "','" + txtPhone.Text + "','" + txtDiseas.Text + "','" + txtDoctorId.Text + "')", con);
                cmd.ExecuteNonQuery();

                if (txtAge.Text != "" && txtDiseas.Text != "" && txtDoctorId.Text != "" && txtPatientId.Text != "" && txtPatientName.Text != "" && txtPhone.Text != "" && txtWeight.Text != "")
                {
                    MessageBox.Show("Data has been saved in database");
                }
                else
                {
                    MessageBox.Show("Data could not be saved");
                }
                con.Close();
            }
            catch (SqlException ex) 
            {
                MessageBox.Show(ex.Message).ToString();
            }
            txtAge.Text = "";
            txtDiseas.Text = "";
            txtDoctorId.Text = "";
            txtPatientId.Text = "";
            txtPatientName.Text = "";
            txtPhone.Text = "";
            txtWeight.Text = "";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            success sc = new success();
            sc.Show();
            this.Hide();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("update patient set name='" + txtPatientName.Text + "', age='" + txtAge.Text + "', weight='"+txtWeight.Text+"',gender='"+comboBoxGender.SelectedItem+"',address='"+richTextAddress.Text+"',phone='"+txtPhone.Text+"',disease='"+txtDiseas.Text+"',doctorid='"+txtDoctorId.Text+"' where pid='" + txtPatientId.Text + "'", con);
                cmd.ExecuteNonQuery();
                if (txtAge.Text != "" && txtDiseas.Text != "" && txtDoctorId.Text != "" && txtPatientId.Text != "" && txtPatientName.Text != "" && txtPhone.Text != "" && txtWeight.Text != "")
                {
                    MessageBox.Show("Update successful");
                }
                else
                {
                    MessageBox.Show("Update not successful");
                }
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("delete from patient where pid='" + txtPatientId.Text + "'", con);
                cmd.ExecuteNonQuery();
                if (txtPatientId.Text != "")
                {
                    MessageBox.Show("Delete successful");
                }
                else
                {
                    MessageBox.Show("Delete not successful");
                }
                con.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            txtPatientId.Clear();
        }
    }
}
